        <footer>
            <div class="footer_links">
                <h1><a href="index.php">CRAP PRINCIPLES</a></h1>  <!--Link to homepage-->
                <p><a href="contrast.php">Contrast</a></p>
                <p><a href="repetition.php">Repetition</a></p>
                <p><a href="alignment.php">Alignment</a></p>
                <p><a href="proximity.php">Proximity</a></p>
                <p><a href="goodBad.php">Good vs Bad</a></p>
                <div class="quiz_section">
                    <div class="quiz_head">
                        <p><a href="#">Quizzes</a></p>
                        <button onclick="buttonToggle()" class="footer_arrow"><img src="assets/pictures/arrowDown_white.svg"></button>
                    </div>
                    <div id="q">
                        <p><a href="contrastQuiz.php">Contrast Quiz</a></p>
                        <p><a href="repetitionQuiz.php">Repetition Quiz</a></p>
                        <p><a href="alignmentQuiz.php">Alignment Quiz</a></p>
                        <p><a href="proximityQuiz.php">Proximity Quiz</a></p>
                    </div>
                </div>
            </div>
            <div class="footer_end">
                <p>Copyright &copy; 2025</p>
            </div>
        </footer>
    </body>
    
</html>